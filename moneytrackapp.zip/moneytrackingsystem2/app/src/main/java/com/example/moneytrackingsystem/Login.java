package com.example.moneytrackingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    Button b1,b2;
    EditText e1,e2;
    FirebaseAuth ma;
public static String dbid;
ImageView i;
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ma=FirebaseAuth.getInstance();
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        e1=(EditText) findViewById(R.id.editText9);
        i=(ImageView)findViewById(R.id.imageView2);

        e2=(EditText) findViewById(R.id.editText10);
        dbid=e1.getText().toString();
        e2.setText(e1.getText().toString());
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ma.signInWithEmailAndPassword(e1.getText().toString(),e2.getText().toString())
                        .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Toast.makeText(Login.this, "signed in", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(Login.this,Welcome.class));
                                    finish();
                                }
                                else {// If sign in fails, display a message to the user.
                                    Toast.makeText(Login.this,"failed",Toast.LENGTH_LONG).show();

                                }

                                // ...
                            }
                        });

            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, MainActivity.class));
                finish();
            }
        });


    }
}
