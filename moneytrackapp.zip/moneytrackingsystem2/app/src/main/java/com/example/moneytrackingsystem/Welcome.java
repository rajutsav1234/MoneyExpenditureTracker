package com.example.moneytrackingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Welcome extends AppCompatActivity {
Button b1,b2,b3;
ImageView i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
    b1=(Button)findViewById(R.id.button4);
    b2=(Button)findViewById(R.id.button5);
    b3=(Button)findViewById(R.id.button6);
    i=(ImageView)findViewById(R.id.imageView) ;
    b1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(Welcome.this,Passbook.class));
            finish();
        }
    });
    b2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(Welcome.this,UPDATE.class));
            finish();
        }
    });
b3.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(Welcome.this,Login.class));
        finish();
    }
});

    }
}
