package com.example.moneytrackingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Passbook extends AppCompatActivity {
DatabaseReference db;
ListView pass;
List<database> datal;
File file;
Button b9,b10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passbook);
        db= FirebaseDatabase.getInstance().getReference(Login.dbid);
        pass=(ListView)findViewById(R.id.listView);
        datal=new ArrayList<>();
        b9=(Button)findViewById(R.id.button9);
        b10=(Button)findViewById(R.id.button10);
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Passbook.this, "Saved at"+file, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                datal.clear();
                for(DataSnapshot passlist: dataSnapshot.getChildren())
                {
                  database g=passlist.getValue(database.class);
                  save(g.getDate(),g.getCategory(),g.getIncome());
datal.add(g);

                }
                listitems adp=new listitems(Passbook.this,datal);
                pass.setAdapter(adp);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Passbook.this,Welcome.class));
                finish();
            }
        });
    }
    public void save(String s1,String s2,String s3)
    {

        s1=s1+" ";
        file=null;

        FileOutputStream fb=null;
        try
        {
            file=getFilesDir();
            fb = openFileOutput("mytext.txt", MODE_APPEND);
            fb.write(s1.getBytes());
            fb.write(s2.getBytes());
            fb.write(s3.getBytes());
        }
        catch (FileNotFoundException mp)
        {
            mp.printStackTrace();
        }
        catch (IOException mp2)
        {
            mp2.printStackTrace();
        }
        finally {
            try {
                fb.close();
            }
            catch (IOException mp3)
            {
                mp3.printStackTrace();
            }

        }

    }
}

