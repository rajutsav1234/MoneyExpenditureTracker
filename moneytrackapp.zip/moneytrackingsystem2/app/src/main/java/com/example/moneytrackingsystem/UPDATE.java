package com.example.moneytrackingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UPDATE extends AppCompatActivity {
Button b1,b2;
TextView t1,t2,t3,t4,t5;
Spinner sp1,sp2,sp3,sp4;
DatabaseReference db;
EditText e1,e2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_u_p_d_a_t_e);
b1=(Button)findViewById(R.id.button7);
        b2=(Button)findViewById(R.id.button8);

        t2=(TextView) findViewById(R.id.textView2);
        t3=(TextView)findViewById(R.id.textView3);
        t3=(TextView) findViewById(R.id.textView4);
        t4=(TextView)findViewById(R.id.textView5);
        sp1=(Spinner)findViewById(R.id.spinner);
        sp2=(Spinner)findViewById(R.id.spinner2);
        sp3=(Spinner)findViewById(R.id.spinner3);
        sp4=(Spinner)findViewById(R.id.spinner4);
        e1=(EditText)findViewById(R.id.editText5);
        e2=(EditText)findViewById(R.id.editText8) ;

 db= FirebaseDatabase.getInstance().getReference(Login.dbid);
b2.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        insertdata();

    }
});
b1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(UPDATE.this,Welcome.class));
        finish();
    }
});
    }

    public void insertdata()
    {
String s1=sp1.getSelectedItem().toString()+sp2.getSelectedItem().toString()+sp3.getSelectedItem().toString();
String s2=sp4.getSelectedItem().toString();
String s3=e1.getText().toString();
double i1=Integer.parseInt(s3);
double i2=Integer.parseInt(e2.getText().toString());
if(i2>=i1)
{
    i2=i2-i1;






if(s3.isEmpty()==false) {
    String id1 = db.push().getKey();
    database data = new database(id1, s1, s2, s3,Double.toString(i2));
    db.child(id1).setValue(data);
    Toast.makeText(UPDATE.this,"Successfully inserted",Toast.LENGTH_LONG).show();

}
else
{
    Toast.makeText(UPDATE.this,"fill the expenditure",Toast.LENGTH_LONG).show();
}}
else Toast.makeText(UPDATE.this,"low balance",Toast.LENGTH_LONG).show();

    }

}
