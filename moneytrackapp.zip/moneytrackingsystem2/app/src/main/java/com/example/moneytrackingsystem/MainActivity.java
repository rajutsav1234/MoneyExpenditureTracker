package com.example.moneytrackingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
Button b3,b1;
TextView t1,t2;
static String waln;



EditText email,password,wal,balance;
FirebaseAuth ma;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ma=FirebaseAuth.getInstance();
        b3=(Button)findViewById(R.id.button3);
        email=(EditText)findViewById(R.id.editText4);
        password=(EditText)findViewById(R.id.editText3);
        wal=(EditText)findViewById(R.id.editText6);
        balance=(EditText)findViewById(R.id.editText7);
        t1=(TextView)findViewById(R.id.textView12);
        t2=(TextView)findViewById(R.id.textView13);
String em=email.getText().toString();
String pass=password.getText().toString();
waln=wal.getText().toString();
if((em.substring(em.indexOf("@")).equals("gmail.com")||em.substring(em.indexOf("@")).equals("outlook.com")))

{
    if(pass.length()>5)
    {
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ma.createUserWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Toast.makeText(MainActivity.this,"registered",Toast.LENGTH_LONG).show();
                                    startActivity(new Intent(MainActivity.this,Login.class));
                                    finish();
                                } else {
                                    // If sign in fails, display a message to the user.
                                  Toast.makeText(MainActivity.this,"failed",Toast.LENGTH_LONG).show();
                                }

                                // ...
                            }
                        });
                startActivity(new Intent(MainActivity.this,Login.class));
                finish();
            }
        });
    }else
Toast.makeText(MainActivity.this,"atleast six characters",Toast.LENGTH_LONG).show();
}

    else Toast.makeText(MainActivity.this,"email incorrect",Toast.LENGTH_LONG).show();
    }

}
