package com.example.moneytrackingsystem;

public class database {
    String id;
    String date;
    String category;
    String income;
    String balance;
    public  database()
    {

    }

    public String getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getCategory() {
        return category;
    }

    public String getIncome() {
        return income;
    }
public String getBalance(){return balance;}
    public database(String id, String date, String category, String income,String balance) {
        this.id = id;
        this.date = date;
        this.category = category;
        this.income = income;
        this.balance=balance;
    }
}
