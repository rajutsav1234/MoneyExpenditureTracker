package com.example.moneytrackingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class profile extends AppCompatActivity {
EditText e1,e4,e2,e3;
Button b,b2;
String email;
TextView textview1;
ImageView im1,im2,im3;
DatabaseReference db;
String val1,val2,val3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        e1=(EditText)findViewById(R.id.editText16);
        e2=(EditText)findViewById(R.id.editText17);
        e3=(EditText)findViewById(R.id.editText18);
        e4=(EditText)findViewById(R.id.editText20);
        b=(Button)findViewById(R.id.button22);
        b2=(Button)findViewById(R.id.button26);
        im1=(ImageView)findViewById(R.id.imageView7);
        im2=(ImageView)findViewById(R.id.imageView8);
        textview1=(TextView)findViewById(R.id.textView16);
        db= FirebaseDatabase.getInstance().getReference("profile").child(Login.dbid.substring(0,Login.dbid.indexOf("@")));

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(profile.this,update_profile.class));
                finish();

            }
        });
b.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(profile.this,Welcome.class));
        finish();
    }
});

    }

    @Override
    protected void onStart() {
        super.onStart();
        e4.setText(Login.dbid);

        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                val1=dataSnapshot.child("balance1").getValue(String.class);
                e1.setText("Rs"+val1);
                e2.setText(dataSnapshot.child("wallet").getValue(String.class));
                e3.setText(dataSnapshot.child("phone").getValue(String.class));
            }            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
