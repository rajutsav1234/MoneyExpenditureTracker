package com.example.moneytrackingsystem;
// passbook page
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Passbook extends AppCompatActivity {
DatabaseReference db;
ListView pass;
List<database> datal;
File file;
public static  float food=0;
    public static  float hou=0;/*hou=house tra=tavel elw=electricity */
    public static  float tra=0;
    public static  float elw=0;
    public static  float rest=0;

Button but9,but13,but10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passbook);
        db= FirebaseDatabase.getInstance().getReference("walwar").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        pass=(ListView)findViewById(R.id.listView);
        datal=new ArrayList<>();
        but9=(Button)findViewById(R.id.button9);
        but13=(Button)findViewById(R.id.button13);
        but10=(Button)findViewById(R.id.button10);
        but10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Passbook.this, "Saved at"+file, Toast.LENGTH_SHORT).show();
            }
        });
        pass.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                database data=datal.get(position);
                Toast.makeText(Passbook.this,data.getId(),Toast.LENGTH_LONG).show();
                update(data.getId());

                return false;
            }
        });
        but13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Passbook.this,piechar.class));
                finish();
            }
        });
    }
public void update(String id1)
{
    try {final String x=id1;
    AlertDialog.Builder dilb=new AlertDialog.Builder(this);// dilb - dialog builder object
    LayoutInflater inflater=getLayoutInflater();
    final View dialogView=inflater.inflate(R.layout.update,null);
    dilb.setTitle("MODIFICATION");

    dilb.setView(dialogView);
    final EditText da=(EditText)dialogView.findViewById(R.id.editText);
    final EditText cat=(EditText)dialogView.findViewById(R.id.editText2);
    final EditText cost=(EditText)dialogView.findViewById(R.id.editText11);
    final EditText inc=(EditText)dialogView.findViewById(R.id.editText15);
    final Button b9=(Button)dialogView.findViewById(R.id.button12);
    final Button b10=(Button)dialogView.findViewById(R.id.button11);
    b9.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
 try{           String da1=da.getText().toString();
            String cat1=cat.getText().toString();
            String cat2=cost.getText().toString();
            String cat3=inc.getText().toString();



            if(TextUtils.isEmpty(da1))
            {
                da.setError("fill");
            }
            if(TextUtils.isEmpty(cat1))
            {
                cat.setError("fill");
            }
            if(TextUtils.isEmpty(cat2))
            {
                cost.setError("fill");
            }
            if(TextUtils.isEmpty(cat3))
            {
                inc.setError("fill");
            }
            updating(x,da1,cat1,cat2,cat3);}
 catch (Exception exe){Toast.makeText(Passbook.this,"fill",Toast.LENGTH_LONG).show();}
        }
    });
    but10.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            delete(x);
        }
    });

    try{dilb.setTitle("updating and deleting ");
    AlertDialog alertDialog=dilb.create();
    alertDialog.show();
}catch (Exception ex2){}}
    catch (Exception ex3)
    {}}
public boolean updating(String id ,String date,String category,String cost,String income)
{// updating elements
    DatabaseReference dlb=FirebaseDatabase.getInstance().getReference("walwar").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(id);
    database drb=new database(id,date,category,cost,income);
    dlb.setValue(drb);
    food=0;
    hou=0;
    tra=0;
    rest=0;
    elw=0;
    onStart();
    Toast.makeText(Passbook.this,"entry removed",Toast.LENGTH_LONG).show();

    return true;

}
public void delete(String id) // deleting elements
{
    DatabaseReference dbre=FirebaseDatabase.getInstance().getReference("walwar").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(id);
    dbre.removeValue();
    food=0;
    hou=0;
    tra=0;
    rest=0;
    elw=0;
    onStart();
    Toast.makeText(Passbook.this,"entry removed",Toast.LENGTH_LONG).show();
}

    @Override
    protected void onStart() {
        super.onStart();
        // accessing elements of databse and creating a list
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                datal.clear();
                for(DataSnapshot passlist: dataSnapshot.getChildren())
                {

                  database g=passlist.getValue(database.class);
                  save(g.getDate(),g.getCategory(),g.getIncome());
                  if(g.getCategory().equals("Food"))
                      food=food+Integer.parseInt(g.income);
                  else if(g.getCategory().equals("Household"))
                      hou=hou+Integer.parseInt(g.getIncome());
                  else if(g.getCategory().equals("Transport"))
                      tra=tra+Integer.parseInt(g.getIncome());
                  else if (g.getCategory().equals("Electricity and water"))
                      elw=elw+Integer.parseInt(g.getIncome());
                  else rest=rest+Integer.parseInt(g.getIncome());

datal.add(g);

                }
                listitems adp=new listitems(Passbook.this,datal);
                pass.setAdapter(adp);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        but9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Passbook.this,Welcome.class));
                finish();
            }
        });
    }
    public void save(String s1,String s2,String s3)
    { // pdf creation

        s1=s1+" ";
        file=null;

        FileOutputStream fb=null;
        try
        {
// fb - file output
            fb = openFileOutput("mytext.txt", MODE_PRIVATE);
            fb.write(s1.getBytes());
            fb.write(s2.getBytes());
            fb.write(s3.getBytes());
            file=getFilesDir();
        }
        catch (FileNotFoundException mp)
        {
            mp.printStackTrace();
        }
        catch (IOException mp2)
        {
            mp2.printStackTrace();
        }
        finally {
            try {                   // mp<> exception objects
                fb.close();
            }
            catch (IOException mp3)
            {
                mp3.printStackTrace();
            }

        }

    }
}

