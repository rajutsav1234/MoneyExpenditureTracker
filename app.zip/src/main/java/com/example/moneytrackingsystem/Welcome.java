package com.example.moneytrackingsystem;
// welcome page
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Welcome extends AppCompatActivity {
Button but1,but2,but3,but4;
ImageView img;

 FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        but1 = (Button) findViewById(R.id.button4);
        but2 = (Button) findViewById(R.id.button5);
        but3 = (Button) findViewById(R.id.button6);
        but4=(Button)findViewById(R.id.button23);
        img = (ImageView) findViewById(R.id.imageView);
        mAuth = FirebaseAuth.getInstance();
        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Welcome.this, Passbook.class));
                finish();
            }
        });
        but2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Welcome.this, UPDATE.class));
                finish();
            }
        });
        but3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();// signing out of user
                startActivity(new Intent(Welcome.this, Login.class));
                finish();
            }
        });
but4.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(Welcome.this,profile.class));
        finish();
    }
});

    }


}
