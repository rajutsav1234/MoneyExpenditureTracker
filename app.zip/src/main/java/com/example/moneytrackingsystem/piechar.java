package com.example.moneytrackingsystem;
// piechart page
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class piechar extends AppCompatActivity {
float costs[]={Passbook.food,Passbook.hou,Passbook.elw,Passbook.tra,Passbook.rest};
String item[]={"Food","Household","Electricity and water","Transport","Rest"};
Button but;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piechar);
        but=(Button)findViewById(R.id.button21);
        setupPieChart();

        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(piechar.this,Passbook.class));
                finish();
            }
        });
    }
    private void setupPieChart()
    {
        List<PieEntry> pie=new ArrayList<>();
        for(int i=0;i<costs.length;i++)
        {
            pie.add(new PieEntry(costs[i],item[i]));

        }
        PieDataSet dataSet=new PieDataSet(pie,"items3");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        PieData pieData=new PieData(dataSet);
        PieChart chart=(PieChart)findViewById(R.id.pie);
        chart.setData(pieData);
        chart.invalidate();
    }
}
