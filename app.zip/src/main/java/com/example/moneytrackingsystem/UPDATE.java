package com.example.moneytrackingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UPDATE extends AppCompatActivity {
Button but1,but2,but3,but4,but20;
TextView text1,text2,text3,text4,text5;
Spinner sp1,sp2,sp3,sp4;// sp for spinner
DatabaseReference db,db2;// database references
EditText edit1,edit2,edit3;
String balanceleft;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_u_p_d_a_t_e);
but1=(Button)findViewById(R.id.button7);
        but2=(Button)findViewById(R.id.button8);
        but3=(Button)findViewById(R.id.button18);
        but4=(Button)findViewById(R.id.button19);


db=FirebaseDatabase.getInstance().getReference("walwar").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        db2= FirebaseDatabase.getInstance().getReference("profile").child(Login.dbid.substring(0,Login.dbid.indexOf("@")));

        text2=(TextView) findViewById(R.id.textView2);
        text3=(TextView)findViewById(R.id.textView3);
        text3=(TextView) findViewById(R.id.textView4);
        text4=(TextView)findViewById(R.id.textView5);
        text5=(TextView)findViewById(R.id.textView15);
        sp1=(Spinner)findViewById(R.id.spinner);
        sp2=(Spinner)findViewById(R.id.spinner2);
        sp3=(Spinner)findViewById(R.id.spinner3);
        sp4=(Spinner)findViewById(R.id.spinner4);
        edit1=(EditText)findViewById(R.id.editText5);
        edit2=(EditText)findViewById(R.id.editText8) ;
        edit3=(EditText)findViewById(R.id.editText14) ;


but3.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {// updating balance
        String val =text5.getText().toString();
        if(TextUtils.isEmpty(edit2.getText().toString()))
            edit2.setError("fill it");
        else
        {

                double upval = Double.parseDouble(val) + Double.parseDouble(edit2.getText().toString());

                db2.child("balance1").setValue(Double.toString(upval));
                Toast.makeText(UPDATE.this, "Successfully added", Toast.LENGTH_LONG).show();
                text5.setText(Double.toString(upval));

        }


    }
});

 but4.setOnClickListener(new View.OnClickListener() {
     @Override
     public void onClick(View v) {// deducting the data
         String val=text5.getText().toString();
         if(TextUtils.isEmpty(edit2.getText().toString()))
             edit2.setError("fill it");
         else
         {
         if(Double.parseDouble(val)>Double.parseDouble(edit2.getText().toString())) {
             double upval = Double.parseDouble(val) - Double.parseDouble(edit2.getText().toString());

             db2.child("balance1").setValue(Double.toString(upval));
             Toast.makeText(UPDATE.this, "Successfully deducted", Toast.LENGTH_LONG).show();
             text5.setText(Double.toString(upval));
         }else Toast.makeText(UPDATE.this,"low balance",Toast.LENGTH_LONG).show();
         }
     }
 });
but2.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        insertdata();

    }
});
but1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(UPDATE.this,Welcome.class));
        finish();
    }
});


    }

    @Override
    protected void onStart() {
        super.onStart();// for showing the balance
db2.addValueEventListener(new ValueEventListener() {
    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
   balanceleft=dataSnapshot.child("balance1").getValue(String.class);
   text5.setText(balanceleft);
    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }
});
    }

    public void insertdata()
    {// inserting the entry into passbook
String s1=sp1.getSelectedItem().toString()+sp2.getSelectedItem().toString()+sp3.getSelectedItem().toString();
String s2=sp4.getSelectedItem().toString();
String s4=edit3.getText().toString();
        String s3=edit1.getText().toString();
if((s2.equals("None"))&&(s4.isEmpty()))
{
    Toast.makeText(UPDATE.this,"fill any other activity",Toast.LENGTH_LONG).show();
}
else if((s2.equals("None"))&&(!(s4.isEmpty())))
{
    s2=s4





    ;
}

    double i1 = Double.parseDouble(s3);
    double i2 = Double.parseDouble(text5.getText().toString());




        if (s3.isEmpty() == false) {
            if(i2>=i1) {
                i2=i2-i1;
                String id1 = db.push().getKey();
                database data = new database(id1, s1, s2, s3, Double.toString(i2));
                db.child(id1).setValue(data);
                Toast.makeText(UPDATE.this, "Successfully inserted", Toast.LENGTH_LONG).show();
                db2.child("balance1").setValue(Double.toString(i2));
                text5.setText(Double.toString(i2));
            }
         else {
            Toast.makeText(UPDATE.this, "low balance", Toast.LENGTH_LONG).show();
        }
    } else Toast.makeText(UPDATE.this, "fill the expenditure", Toast.LENGTH_LONG).show();
}
    }


