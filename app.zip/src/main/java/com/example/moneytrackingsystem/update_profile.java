package com.example.moneytrackingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class update_profile extends AppCompatActivity {
EditText walt,balan,phone;
Button update,back;
ImageView im1,im2,im3;
    DatabaseReference dbase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);
    dbase= FirebaseDatabase.getInstance().getReference("profile").child(Login.dbid.substring(0,Login.dbid.indexOf("@")));
            walt=(EditText)findViewById(R.id.editText23);
        balan=(EditText)findViewById(R.id.editText21);
        phone=(EditText)findViewById(R.id.editText22);
        back=(Button)findViewById(R.id.button25);
        im1=(ImageView)findViewById(R.id.imageView4);
        im2=(ImageView)findViewById(R.id.imageView5);
        im3=(ImageView)findViewById(R.id.imageView6);
        update=(Button)findViewById(R.id.button20);
update.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if((walt.getText().toString().isEmpty())||(phone.getText().toString().isEmpty())||(balan.getText().toString().isEmpty()))
            Toast.makeText(update_profile.this, "fill all the details", Toast.LENGTH_SHORT).show();
        else{
            dbase.child("phone").setValue(phone.getText().toString());
        dbase.child("balance1").setValue(balan.getText().toString());
        dbase.child("wallet").setValue(walt.getText().toString());
            Toast.makeText(update_profile.this, "updated successfully", Toast.LENGTH_SHORT).show();
    }}
});
back.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(update_profile.this,profile.class));
        finish();
    }
});
    }
}
