package com.example.moneytrackingsystem;

import androidx.appcompat.app.AppCompatActivity;

public class profiledetails  {
    String id1;
    String wallet;

    String phone;
    String balance1;
    public profiledetails()
    {

    }

    public String getId() {
        return id1;
    }

    public String getWallet() {
        return wallet;
    }

    public String getPhone() {
        return phone;
    }

    public String getBalance1() {
        return balance1;
    }

    public profiledetails(String id1, String wallet, String phone, String balance1) {
        this.id1 = id1;
        this.wallet = wallet;
        this.phone = phone;
        this.balance1 = balance1;
    }


}
