package com.example.moneytrackingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
// login page
public class Login extends AppCompatActivity {

    Button but1,but2,but3;//but<> for buttons
    EditText edit1,edit2;//edit<> for edittext
    FirebaseAuth ma;//ma refernce user
public static String  dbid,email;
ImageView i;
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ma=FirebaseAuth.getInstance();
        but1=(Button)findViewById(R.id.button14);
        but2=(Button)findViewById(R.id.button2);
        but3=(Button)findViewById(R.id.button24);
        edit1=(EditText) findViewById(R.id.editText9);
        i=(ImageView)findViewById(R.id.imageView2);

        edit2=(EditText) findViewById(R.id.editText10);


        but2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // signing in of user
                ma.signInWithEmailAndPassword(edit1.getText().toString(),edit2.getText().toString())
                        .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    dbid=(edit1.getText().toString());
                                    Toast.makeText(Login.this, "signed in", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(Login.this,Welcome.class));
                                    finish();

                                }
                                else {// If sign in fails, display a message to the user.
                                    Toast.makeText(Login.this,"failed",Toast.LENGTH_LONG).show();

                                }

                                // ...
                            }
                        });

            }
        });
        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, Register.class));
                finish();
            }
        });

but3.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        // reset password
      try{ final EditText resetmail=new EditText(v.getContext());
       final AlertDialog.Builder passwdresetdialog=new AlertDialog.Builder(v.getContext());
       passwdresetdialog.setTitle("RESET PASSWORD");
       passwdresetdialog.setMessage("enter your email for verification link");
       passwdresetdialog.setView(resetmail);

       passwdresetdialog.setPositiveButton("yes", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int which) {
               String mail=resetmail.getText().toString();
               ma.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                   @Override
                   public void onSuccess(Void aVoid) {
                       Toast.makeText(Login.this, "Link sent to your mail", Toast.LENGTH_SHORT).show();
                   }
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       Toast.makeText(Login.this, "Error :"+e.getMessage(), Toast.LENGTH_SHORT).show();
                   }
               });
           }
       });
       passwdresetdialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int which) {

           }
       });
       AlertDialog alertDialog=passwdresetdialog.create();
        alertDialog.show();
    }catch(IllegalArgumentException ex1)
      {
          Toast.makeText(Login.this, "fill the email", Toast.LENGTH_SHORT).show();
      }
    catch (Exception ex2)
    {}}

});
    }
}
