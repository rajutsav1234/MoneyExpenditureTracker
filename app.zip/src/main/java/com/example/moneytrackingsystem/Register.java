package com.example.moneytrackingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
// register page
public class Register extends AppCompatActivity {
Button but3,but1;
TextView text1,text2;
static String waln;



EditText email,password,wal,balance,ph;
FirebaseAuth ma;// firebase authentication refernce
DatabaseReference db2;//db2 database refernce
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ma = FirebaseAuth.getInstance();
        but3 = (Button) findViewById(R.id.button3);
        email = (EditText) findViewById(R.id.editText4);
        password = (EditText) findViewById(R.id.editText3);
        wal = (EditText) findViewById(R.id.editText6);
        balance = (EditText) findViewById(R.id.editText7);
        ph = (EditText) findViewById(R.id.editText19);
        text1 = (TextView) findViewById(R.id.textView12);
        text2 = (TextView) findViewById(R.id.textView13);

        String pass = password.getText().toString();
        waln = wal.getText().toString();


        but3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((mail(email.getText().toString()) == true)&&
                (passcheck(password.getText().toString()) == true))
                {
// creating user
                    ma.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                            .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Sign in success, update UI with the signed-in user's information
                                        Toast.makeText(Register.this, "registered", Toast.LENGTH_LONG).show();

                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Toast.makeText(Register.this, "failed", Toast.LENGTH_LONG).show();
                                    }

                                    // ...
                                }
                            });
                    String em1=email.getText().toString();// email characterisation
                    String em2=em1.substring(0,em1.indexOf("@"));
                    db2=FirebaseDatabase.getInstance().getReference("profile").child(em2);

                    insertdetails();

                    startActivity(new Intent(Register.this, Login.class));
                    finish();
                }
                else Toast.makeText(Register.this
                ,"invalid email/password(atlest six characters)"+mail(email.getText().toString())+email.getText().toString(),Toast.LENGTH_LONG).show();
            }

        });


    }
    public void insertdetails() //inserting details of user
    {
        String s1=wal.getText().toString();
        String s2=ph.getText().toString();
        String s3=balance.getText().toString();
        if((s1.isEmpty())||(s2.isEmpty())||(s3.isEmpty()))
        {
            Toast.makeText(Register.this,"fill all details",Toast.LENGTH_LONG).show();

        }
        else
        {
            String id1=db2.push().getKey();
            profiledetails pf=new profiledetails(id1,s1,s2,s3);
            db2.setValue(pf);
            Toast.makeText(Register.this,"properly registered",Toast.LENGTH_LONG).show();

        }
    }
public boolean passcheck(String pass) // method for password check
{
    if((pass.length()<6)&&(pass.isEmpty()))
    {
        return false;
    }
    else return true;
}
public boolean mail(String mail)// method for mail check
{
    int at=mail.indexOf("@");
    int lat=mail.lastIndexOf("@");
    int dot=mail.indexOf(".");
    int ldot=mail.lastIndexOf(".");
    if(mail.isEmpty()) {
        return false;
    }
    if((at==lat)&&(dot==ldot))
    {
        if(((mail.substring(at,dot).equals("@gmail"))||(mail.substring(at,dot).equals("@outlook")))&&(mail.substring(ldot+1).equals("com")))
        {
            return true;
        }
        else if(mail.substring(dot).equals(".org"))
        {
            return true;
        }
        else return false;
    }
    else return false;
}}

