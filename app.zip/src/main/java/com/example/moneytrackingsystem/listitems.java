package com.example.moneytrackingsystem;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class listitems extends ArrayAdapter<database> {
    public Activity context;
    public List<database> datalist;

    public listitems( Activity context, List<database> datalist) {
        super(context,R.layout.list_layout,datalist);
        this.context = context;
        this.datalist = datalist;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater=context.getLayoutInflater();

        View listViewitem =inflater.inflate(R.layout.list_layout,null,true);
        TextView textViewDate=(TextView)listViewitem.findViewById(R.id.textView8);
        TextView textViewCategory=(TextView)listViewitem.findViewById(R.id.textView9);
        TextView textViewIncome=(TextView)listViewitem.findViewById(R.id.textView10);
        TextView textwal=(TextView)listViewitem.findViewById(R.id.textView11) ;
        database gro2=datalist.get(position);
        textViewDate.setText(gro2.getDate());
        textViewIncome.setText(gro2.getIncome());
        textViewCategory.setText(gro2.getCategory());
        textwal.setText(gro2.getBalance());

        return listViewitem;
    }
}
